"""Cấu hình hypotheses Q&A để cache/portfolio có thể replay mà không hardcode."""

from __future__ import annotations

import os
from pathlib import Path


ANSWER_MODES = (
    "visual_count",
    "visual_read",
    "ocr",
    "asr",
    "metadata",
    "visual_attribute",
)

# H02: không loại số 0; placeholder đếm được nhận qua provenance/hash lịch sử.
QA_PLACEHOLDER_ANSWERS = frozenset({"todo", "no_answer", "chua_co_answer"})
QA_PLACEHOLDER_PROVENANCE_TOKENS = frozenset({"placeholder", "no_answer"})
QA_OPERATOR_PROVENANCE_TOKENS = frozenset({"operator_evidence", "operator_assisted", "manual_verified", "manual_override"})
QA_AUTONOMOUS_PROVENANCE_TOKENS = frozenset({"llm", "detector", "autonomous"})

# Tăng version khi prompt/schema planner hoặc prompt suy luận đổi nghĩa.
QA_PLANNER_PROMPT_VERSION = "qa-planner-v2"
QA_INFERENCE_PROMPT_VERSION = "qa-evidence-v2"
QA_HYPOTHESIS_CACHE_SCHEMA_VERSION = 1

# Canonical của mọi hypothesis luôn đi trước; sau đó mỗi hypothesis chỉ chiếm
# tối đa một frame thay thế trước khi phần đuôi phủ candidate retrieval mới.
QA_HYPOTHESIS_ALTERNATIVES_PER_HYPOTHESIS = 1

# Sentinel không mang bằng chứng trả lời; normalize case/whitespace ở caller.
QA_SENTINEL_ANSWERS = frozenset({
    "không đủ căn cứ",
    "không có thông tin",
    "không đủ thông tin",
    "insufficient evidence",
    "no information",
    "not enough information",
})

# Chỉ reject prefix khi token kế tiếp là một continuation mang nghĩa "không có
# evidence". Nhờ vậy answer thật như "No Information Technology" hay
# "Không có thông tin liên lạc" không bị loại chỉ vì cùng tiền tố.
QA_SENTINEL_PREFIX_CONTINUATIONS = frozenset({
    "để", "trong", "từ", "về", "được", "có", "nhằm",
    "is", "was", "to", "in", "from", "about", "available", "provided",
})

# ---------------------------------------------------------------- dò TỪ CHỐI
# Danh sách chuỗi ở trên là danh sách ĐÓNG, mà LLM đẻ biến thể vô hạn. Đo thật
# (28/08, đề đợt 1): 6 chuỗi trên chỉ bắt được 1/5 câu từ chối thực tế —
# "Không thể xác định từ bằng chứng", "Không có cân hiển thị trong hình ảnh",
# "Không thấy cân hoặc số trên cân", "Không đủ bằng chứng" đều lọt vì sai một
# chữ. Nên chuyển sang dò HÌNH DẠNG: phủ định + từ nói về việc thiếu bằng chứng.
QA_REFUSAL_NEGATIONS = frozenset({
    "không", "chưa", "chẳng",
    "no", "not", "cannot", "unable", "insufficient",
})

# CỐ Ý không có "thông tin"/"information"/"dữ liệu": chúng xuất hiện trong đáp
# án THẬT ("Không có thông tin liên lạc", "No Information Technology") nên dò
# theo chúng là loại nhầm. Chỉ giữ từ nói về việc NHÌN/ĐỌC được bằng chứng —
# những từ này chỉ xuất hiện khi model đang từ chối, không xuất hiện trong đáp
# án thật. Các chuỗi "không có thông tin ..." vẫn do QA_SENTINEL_ANSWERS bắt.
#
# ⚠️ THU HẸP 03/09 khi gộp nhánh Thạch. Bản cũ còn có "thấy", "hiển thị",
# "quan sát", "trong hình", "trong ảnh", "visible" — và chính chúng LOẠI NHẦM
# đáp án thật, test của Thạch bắt được hai ca:
#     "Không thấy mưa"             -> "thấy"     -> bị loại SAI
#     "Không có người trong ảnh"   -> "trong ảnh" -> bị loại SAI
# Loại nhầm đắt hơn bỏ sót: bỏ sót thì nộp một câu từ chối (0 điểm câu đó),
# loại nhầm thì vứt một đáp án ĐÚNG (cũng 0 điểm, mà lại còn tưởng mình đang
# lọc rác). Hai surface "cân" mà bộ rộng từng bắt được nay nằm ở
# QA_REFUSAL_EXACT_ANSWERS bên dưới — chặn đích danh, không quét bằng lưới rộng.
QA_REFUSAL_EVIDENCE_WORDS = frozenset({
    "xác định", "đọc được", "nhận diện", "bằng chứng", "căn cứ",
    "determine", "identify", "legible", "discern", "evidence",
})

# Chỉ dò khi answer đủ dài. "Không" (câu có/không) và "0" (câu đếm) là đáp án
# THẬT — luật dài >= 2 từ giữ chúng lại.
# 2 chứ không phải 3: "Cannot determine" đúng 2 từ và là câu từ chối thật.
QA_REFUSAL_MIN_WORDS = 2

# Hai surface QUAN SÁT ĐƯỢC THẬT trong run đợt 1, chặn đích danh vì luật hình
# dạng không với tới: chúng nói "không nhìn thấy X" chứ không nhắc tới việc xác
# định hay bằng chứng, nên mọi từ khoá đủ hẹp để an toàn đều trượt chúng.
# Khớp TRỌN VẸN cả answer. Thêm vào đây chỉ khi đã thấy surface đó trong log thật.
QA_REFUSAL_EXACT_ANSWERS = frozenset({
    "không có cân hiển thị trong hình ảnh",
    "không thấy cân hoặc số trên cân trong hình",
})

# Câu từ chối NGẮN — lỗ hổng của luật dò theo hình dạng ở trên. Nhập từ nhánh
# `codex/qa-last-3h` của Thạch khi gộp 03/09: luật `>= 3 từ` cố ý bỏ qua answer
# ngắn để giữ "Không"/"0", nhưng chính vì thế mà "không biết", "không rõ",
# "not sure", "unclear" đi thẳng vào bài nộp làm đáp án. Kiểm bằng code trước
# khi gộp: 9/9 surface dưới đây lọt qua `is_valid_qa_answer` của bản dot3.
#
# Đây là danh sách ĐÓNG và chỉ được phép chứa chuỗi KHÔNG BAO GIỜ là đáp án
# thật — khớp TRỌN VẸN cả answer, không phải khớp một phần. Không nhồi thêm
# chuỗi dài vào đây: việc đó thuộc luật hình dạng phía trên.
QA_REFUSAL_SHORT_ANSWERS = frozenset({
    "không biết", "không rõ", "chưa rõ", "không chắc",
    "not sure", "unclear", "unknown",
    "don't know", "do not know", "i don't know", "i do not know",
})

# Chủ ngữ đứng trước câu từ chối, bóc ra rồi mới so với danh sách trên:
# "tôi không biết" và "không biết" là cùng một câu từ chối.
QA_REFUSAL_SUBJECT_PREFIXES = frozenset({"tôi", "mình", "i", "we"})

# ------------------------------------------------- kiểu đáp án theo answer_mode
# Đáp án phải đúng DẠNG mà câu hỏi đòi. Đo thật: p1-17 hỏi "tên con đèo là gì"
# mà hạng 1 là "Chồn Hương" (tên con vật) trong khi "Đèo Bạch Mã" nằm hạng 2 —
# hai bên hoà confidence 0.62, không có gì phá hoà theo đúng kiểu câu hỏi.
#   digit  = bắt buộc chứa chữ số
#   short  = cụm danh từ ngắn, không quá số từ cho phép
QA_ANSWER_MODE_RULES: dict[str, dict[str, object]] = {
    "visual_count": {"digit": True, "max_words": 4},
    "visual_read": {"digit": False, "max_words": 8},
    "ocr": {"digit": False, "max_words": 8},
    "asr": {"digit": False, "max_words": 12},
    "metadata": {"digit": False, "max_words": 8},
    "visual_attribute": {"digit": False, "max_words": 8},
}

# ------------------------------------------------------- phạt theo hạng retrieval
# Q&A có HAI cửa tử độc lập: sai video = 0 dù answer đúng. Đo thật: winner của
# p1-3 là shot hạng 104 và p1-15 là hạng 105 — chọn thuần theo confidence tự
# khai, mà confidence lại bị ĐẢO NGƯỢC (câu từ chối "không thấy cân" được 0.60
# vì "không thấy gì" là quan sát dễ, còn đọc số mờ thật thì model chỉ dám 0.30).
# Phạt theo log10 hạng: hạng 1 -> 0, hạng 10 -> -0.15, hạng 100 -> -0.30.
QA_WINNER_RANK_PENALTY = 0.15

# Khi KHÔNG shot nào trả lời được: nộp bấy nhiêu VIDEO đầu bảng retrieval, mỗi
# video một dòng, xếp đúng thứ tự retrieval. Đáp án lúc đó vô nghĩa nên tín hiệu
# duy nhất còn giá trị là "đào video nào trước" — 10 video vừa đủ để người soi
# lướt trong ngân sách vài phút mà không bỏ sót video đúng.
QA_PLACEHOLDER_VIDEOS = 10

# ------------------------------------------------- bù shot KHÔNG có keyframe
# Keyframe BTC thưa và thưa KHÔNG ĐỀU. Đo 28/08 (query-p1-3-qa, đáp án thật
# L21_V023 frame 26050): keyframe gần nhất là 25495 và 26906 — một khoảng 1411
# frame (~47 giây) không có vector nào, và shot chứa đáp án nằm gọn trong đó.
# Tìm kiếm vector không thể với tới vùng này, nên phải tự phát shot cho nó.
# 3 video × 30 shot = tối đa 90 slot, vẫn còn chỗ cho ứng viên thật.
# Phủ RỘNG hơn chứ đừng sâu: đo được video đúng của p1-3 đứng hạng 9, nếu chỉ
# bù cho 3 video đầu thì nó không được bù. Điểm shot bù bám ngay dưới video mẹ
# nên phủ rộng không làm loãng đầu bảng.
QA_GAP_FILL_VIDEOS = 12
QA_GAP_FILL_SHOTS_PER_VIDEO = 12


def qa_hypothesis_cache_dir() -> Path:
    """Đường cache có thể đổi bằng env cho test/job; caller không tự ghép path."""
    configured = os.environ.get("QA_HYPOTHESIS_CACHE_DIR", "").strip()
    if configured:
        return Path(configured)
    return Path(__file__).resolve().parents[2] / "data" / "cache" / "qa_hypotheses"


def qa_hypothesis_config_snapshot() -> dict[str, object]:
    """Snapshot JSON-safe của knobs ảnh hưởng identity và thứ tự portfolio."""
    return {
        "answer_modes": list(ANSWER_MODES),
        "planner_prompt_version": QA_PLANNER_PROMPT_VERSION,
        "inference_prompt_version": QA_INFERENCE_PROMPT_VERSION,
        "cache_schema_version": QA_HYPOTHESIS_CACHE_SCHEMA_VERSION,
        "alternatives_per_hypothesis": QA_HYPOTHESIS_ALTERNATIVES_PER_HYPOTHESIS,
        "sentinel_answers": sorted(QA_SENTINEL_ANSWERS),
        "sentinel_prefix_continuations": sorted(QA_SENTINEL_PREFIX_CONTINUATIONS),
        "refusal_negations": sorted(QA_REFUSAL_NEGATIONS),
        "refusal_evidence_words": sorted(QA_REFUSAL_EVIDENCE_WORDS),
        "refusal_min_words": QA_REFUSAL_MIN_WORDS,
        "answer_mode_rules": {k: dict(v) for k, v in sorted(QA_ANSWER_MODE_RULES.items())},
        "winner_rank_penalty": QA_WINNER_RANK_PENALTY,
    }
